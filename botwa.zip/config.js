module.exports = {
    API_KEY_RM_BG: "EZ3HDswwbfy7tXgKTfmhbAdY",
    API_KEY_OPEN_AI: "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"
}